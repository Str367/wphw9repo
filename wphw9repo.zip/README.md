# Web Programming HW5(僅完成基本要求)

## 載下來後麻煩分別到backend跟frontend裡面執行npm install(因為我沒有push node module上去，所以麻煩幫我install一下)    
然後記得放自己的.env檔案 感謝
